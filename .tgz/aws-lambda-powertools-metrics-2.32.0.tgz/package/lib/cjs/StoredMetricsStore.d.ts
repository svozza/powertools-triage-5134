import type { StoredMetric } from './types/index.js';
/**
 * Manages storage of metrics with automatic context detection.
 *
 * This class abstracts the storage mechanism for metrics, automatically
 * choosing between AsyncLocalStorage (when in async context) and a fallback
 * object (when outside async context). The decision is made at runtime on
 * every method call to support Lambda's transition to async contexts.
 */
declare class StoredMetricsStore {
    #private;
    getMetric(name: string): StoredMetric | undefined;
    setMetric(name: string, metric: StoredMetric): void;
    getMetricNames(): string[];
    getAllMetrics(): StoredMetric[];
    clearMetrics(): void;
    hasMetrics(): boolean;
    getMetricsCount(): number;
}
export { StoredMetricsStore };
//# sourceMappingURL=StoredMetricsStore.d.ts.map