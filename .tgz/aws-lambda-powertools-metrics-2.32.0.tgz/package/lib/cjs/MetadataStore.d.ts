import '@aws/lambda-invoke-store';
/**
 * Manages storage of metrics #metadata with automatic context detection.
 *
 * This class abstracts the storage mechanism for metrics, automatically
 * choosing between AsyncLocalStorage (when in async context) and a fallback
 * object (when outside async context). The decision is made at runtime on
 * every method call to support Lambda's transition to async contexts.
 */
declare class MetadataStore {
    #private;
    set(key: string, value: string): string;
    getAll(): Record<string, string>;
    clear(): void;
}
export { MetadataStore };
//# sourceMappingURL=MetadataStore.d.ts.map