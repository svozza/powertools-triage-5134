import '@aws/lambda-invoke-store';
import type { MetricResolution, MetricUnit, StoredMetric } from './types/index.js';
/**
 * Manages storage of metrics with automatic context detection.
 *
 * This class abstracts the storage mechanism for metrics, automatically
 * choosing between AsyncLocalStorage (when in async context) and a fallback
 * object (when outside async context). The decision is made at runtime on
 * every method call to support Lambda's transition to async contexts.
 */
declare class MetricsStore {
    #private;
    getMetric(name: string): StoredMetric | undefined;
    /**
     * Adds a metric value to storage. If a metric with the same name already exists,
     * the value is appended to an array. Validates that the unit matches any existing metric.
     *
     * @example
     * ```typescript
     * store.setMetric('latency', MetricUnit.Milliseconds, 100);
     * // Returns: { name: 'latency', unit: 'Milliseconds', value: 100, resolution: 60 }
     *
     * store.setMetric('latency', MetricUnit.Milliseconds, 150);
     * // Returns: { name: 'latency', unit: 'Milliseconds', value: [100, 150], resolution: 60 }
     * ```
     *
     * @param name - The metric name
     * @param unit - The metric unit (must match existing metric if present)
     * @param value - The metric value to add
     * @param resolution - The metric resolution (defaults to Standard)
     * @returns The stored metric with updated values
     * @throws Error if unit doesn't match existing metric
     */
    setMetric(name: string, unit: MetricUnit, value: number, resolution?: MetricResolution): StoredMetric;
    getMetricNames(): string[];
    getAllMetrics(): StoredMetric[];
    clearMetrics(): void;
    hasMetrics(): boolean;
    getMetricsCount(): number;
    getTimestamp(): number | undefined;
    setTimestamp(timestamp: number | Date): number;
}
export { MetricsStore };
//# sourceMappingURL=MetricsStore.d.ts.map