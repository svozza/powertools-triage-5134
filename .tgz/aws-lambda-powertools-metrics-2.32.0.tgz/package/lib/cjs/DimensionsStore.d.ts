import '@aws/lambda-invoke-store';
import type { Dimensions } from './types/Metrics.js';
/**
 * Manages storage of metrics dimensions with automatic context detection.
 *
 * This class abstracts the storage mechanism for metrics, automatically
 * choosing between AsyncLocalStorage (when in async context) and a fallback
 * object (when outside async context). The decision is made at runtime on
 * every method call to support Lambda's transition to async contexts.
 */
declare class DimensionsStore {
    #private;
    addDimension(name: string, value: string): string;
    addDimensionSet(dimensionSet: Dimensions): Dimensions;
    getDimensions(): Dimensions;
    getDimensionSets(): Dimensions[];
    clearRequestDimensions(): void;
    clearDefaultDimensions(): void;
    getDimensionCount(): number;
    setDefaultDimensions(dimensions: Dimensions): void;
    getDefaultDimensions(): Dimensions;
}
export { DimensionsStore };
//# sourceMappingURL=DimensionsStore.d.ts.map