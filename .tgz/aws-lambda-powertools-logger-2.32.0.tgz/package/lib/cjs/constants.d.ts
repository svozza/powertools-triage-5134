/**
 * The indent level for JSON logs.
 *
 * By default Logger will use the `LogJsonIndent.COMPACT` indent level, which
 * produces logs on a single line. This is the most efficient option for
 * CloudWatch Logs.
 *
 * When enabling the `POWERTOOLS_DEV` environment variable, Logger will use the
 * `LogJsonIndent.PRETTY` indent level, which indents the JSON logs for easier
 * reading.
 */
declare const LogJsonIndent: {
    readonly PRETTY: 4;
    readonly COMPACT: 0;
};
declare const LogLevel: {
    readonly TRACE: "TRACE";
    readonly DEBUG: "DEBUG";
    readonly INFO: "INFO";
    readonly WARN: "WARN";
    readonly ERROR: "ERROR";
    readonly SILENT: "SILENT";
    readonly CRITICAL: "CRITICAL";
};
/**
 * Numeric values for each log level.
 */
declare const LogLevelThreshold: {
    readonly TRACE: 6;
    readonly DEBUG: 8;
    readonly INFO: 12;
    readonly WARN: 16;
    readonly ERROR: 20;
    readonly CRITICAL: 24;
    readonly SILENT: 28;
};
/**
 * Reserved keys that are included in every log item when using the default log formatter.
 *
 * These keys are reserved and cannot be overwritten by custom log attributes.
 */
declare const ReservedKeys: string[];
/**
 * Message logged when an uncaught error occurs in a Lambda function.
 */
declare const UncaughtErrorLogMessage = "Uncaught error detected, flushing log buffer before exit";
export { LogJsonIndent, LogLevel, LogLevelThreshold, ReservedKeys, UncaughtErrorLogMessage, };
//# sourceMappingURL=constants.d.ts.map