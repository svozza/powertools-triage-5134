import type { PowertoolsLogFormatterOptions } from '../types/formatters.js';
import type { LogAttributes, UnformattedAttributes } from '../types/logKeys.js';
import { LogFormatter } from './LogFormatter.js';
import { LogItem } from './LogItem.js';
/**
 * This class is used to transform a set of log key-value pairs
 * in the Powertools for AWS Lambda default structure log format.
 *
 * @class
 * @extends {LogFormatter}
 */
declare class PowertoolsLogFormatter extends LogFormatter {
    #private;
    constructor(options?: PowertoolsLogFormatterOptions);
    /**
     * It formats key-value pairs of log attributes.
     *
     * @param {UnformattedAttributes} attributes - unformatted attributes
     * @param {LogAttributes} additionalLogAttributes - additional log attributes
     */
    formatAttributes(attributes: UnformattedAttributes, additionalLogAttributes: LogAttributes): LogItem;
}
export { PowertoolsLogFormatter };
//# sourceMappingURL=PowertoolsLogFormatter.d.ts.map