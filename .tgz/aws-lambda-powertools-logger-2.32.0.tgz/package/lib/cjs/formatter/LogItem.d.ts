import type { LogAttributes } from '../types/Logger.js';
/**
 * LogItem is a class that holds the attributes of a log item.
 *
 * It is used by {@link LogFormatter} to store the attributes of a log item and to add additional attributes to it.
 */
declare class LogItem {
    /**
     * The attributes of the log item.
     */
    private attributes;
    /**
     * Constructor for LogItem.
     *
     * Attributes are added in the following order:
     * - Standard keys provided by the logger (e.g. `message`, `level`, `timestamp`)
     * - Persistent attributes provided by developer, not formatted (done later)
     * - Ephemeral attributes provided as parameters for a single log item (done later)
     *
     * @param params - The parameters for the LogItem.
     */
    constructor(params: {
        attributes: LogAttributes;
    });
    /**
     * Add attributes to the log item.
     *
     * @param attributes - The attributes to add to the log item.
     */
    addAttributes(attributes: LogAttributes): this;
    /**
     * Get the attributes of the log item.
     */
    getAttributes(): LogAttributes;
    /**
     * Prepare the log item for printing.
     *
     * This operation removes empty keys from the log item, see {@link removeEmptyKeys | removeEmptyKeys()} for more information.
     */
    prepareForPrint(): void;
    /**
     * Remove empty keys from the log item, where empty keys are defined as keys with
     * values of `undefined`, empty strings (`''`), or `null`.
     *
     * @param attributes - The attributes to remove empty keys from.
     */
    removeEmptyKeys(attributes: LogAttributes): LogAttributes;
    /**
     * Replace the attributes of the log item.
     *
     * @param attributes - The attributes to set for the log item.
     */
    setAttributes(attributes: LogAttributes): void;
}
export { LogItem };
//# sourceMappingURL=LogItem.d.ts.map