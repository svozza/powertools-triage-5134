import '@aws/lambda-invoke-store';
import type { LogAttributes } from './types/logKeys.js';
/**
 * Manages storage of log attributes with automatic context detection.
 *
 * This class abstracts the storage mechanism for log attributes, automatically
 * choosing between AsyncLocalStorage (when in async context) and a fallback
 * object (when outside async context). The decision is made at runtime on
 * every method call to support Lambda's transition to async contexts.
 */
declare class LogAttributesStore {
    #private;
    appendTemporaryKeys(attributes: LogAttributes): void;
    removeTemporaryKeys(keys: string[]): void;
    getTemporaryAttributes(): LogAttributes;
    clearTemporaryAttributes(): void;
    setPersistentAttributes(attributes: LogAttributes): void;
    getPersistentAttributes(): LogAttributes;
    getAllAttributes(): LogAttributes;
    removePersistentKeys(keys: string[]): void;
}
export { LogAttributesStore };
//# sourceMappingURL=LogAttributesStore.d.ts.map