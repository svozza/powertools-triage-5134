/**
 * This function is used to search for a correlation ID in the event data and is a wrapper
 * around the JMESPath search function. It allows you to specify a JMESPath expression
 * to extract the correlation ID from the event data.
 * @param expression - The JMESPath expression to use for searching the correlation ID.
 * @param data - The event data to search in.
 */
declare const search: (expression: string, data: unknown) => unknown;
/**
 * The correlationPaths object contains the JMESPath expressions for extracting the correlation ID for various AWS services.
 */
declare const correlationPaths: {
    /**
     * API Gateway REST API request ID
     */
    readonly API_GATEWAY_REST: "requestContext.requestId";
    /**
     * API Gateway HTTP API request ID
     */
    readonly API_GATEWAY_HTTP: "requestContext.requestId";
    /**
     * AppSync API request ID
     */
    readonly APPSYNC_AUTHORIZER: "requestContext.requestId";
    /**
     * AppSync resolver X-Ray trace ID
     */
    readonly APPSYNC_RESOLVER: "request.headers.\"x-amzn-trace-id\"";
    /**
     * ALB X-Ray trace ID
     */
    readonly APPLICATION_LOAD_BALANCER: "headers.\"x-amzn-trace-id\"";
    /**
     * EventBridge event ID
     */
    readonly EVENT_BRIDGE: "id";
    /**
     * Lambda Function URL request ID
     */
    readonly LAMBDA_FUNCTION_URL: "requestContext.requestId";
    /**
     * S3 Object trigger request ID
     */
    readonly S3_OBJECT_LAMBDA: "xAmzRequestId";
    /**
     * VPC Lattice X-Ray trace ID
     */
    readonly VPC_LATTICE: "headers.\"x-amzn-trace-id\"";
};
export { correlationPaths, search };
//# sourceMappingURL=correlationId.d.ts.map