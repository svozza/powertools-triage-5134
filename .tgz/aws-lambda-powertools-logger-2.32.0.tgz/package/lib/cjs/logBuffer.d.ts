/**
 * A data structure that holds a value and its byte size.
 *
 * @internal
 */
export declare class SizedItem<V> {
    value: V;
    logLevel: number;
    byteSize: number;
    constructor(value: V, logLevel: number);
}
/**
 * A set that tracks its current byte size.
 *
 * @internal
 */
export declare class SizedSet<V> extends Set<SizedItem<V>> {
    currentBytesSize: number;
    hasEvictedLog: boolean;
    /**
     * Adds an item to the set and updates the current byte size.
     *
     * @param item - The item to add
     */
    add(item: SizedItem<V>): this;
    /**
     * Deletes an item from the set and updates the current byte size.
     *
     * @param item - The item to delete
     */
    delete(item: SizedItem<V>): boolean;
    /**
     * Clears all items from the set and resets the current byte size.
     */
    clear(): void;
    /**
     * Removes the first item from the set and returns it.
     */
    shift(): SizedItem<V> | undefined;
}
/**
 * A ring buffer that stores logs in a circular manner.
 *
 * @internal
 */
export declare class CircularMap<V> extends Map<string, SizedSet<V>> {
    #private;
    constructor({ maxBytesSize, onBufferOverflow, }: {
        maxBytesSize: number;
        onBufferOverflow?: () => void;
    });
    /**
     * Adds an item to the buffer, evicting older items if necessary.
     *
     * @param key - The key to associate with the item
     * @param value - The item to add
     * @param logLevel - The log level of the item
     */
    setItem(key: string, value: V, logLevel: number): this;
}
//# sourceMappingURL=logBuffer.d.ts.map